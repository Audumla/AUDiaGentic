---
id: task-352
label: Freeze validation categories and preservation defaults
state: draft
summary: Define validation failures, compatibility checks, preservation defaults, and config extension seams.
spec_ref: spec-82
request_refs:
- request-32
standard_refs:
- standard-4
- standard-5
- standard-6
---

# Description

Make validation informative and generic instead of hardcoded-known-id or fail.

# Inputs

Read before starting:
- `docs/installer/resolution-reconcile-contract.md` (output from task-351)
- `spec-82` — resolution/validation spec
- `src/audiagentic/foundation/contracts/` — existing contract validation
- `tools/validation/validate_ids.py` — existing ID validation
- `standard-4` — review findings and evidence standard
- `standard-5` — verification and test evidence standard

# Scope coordination

This task defines validation categories and examples. `task-351` owns the shared resolution and reconcile flow. Do not redefine precedence or mode semantics here.

# Blocker handling

- if a proposed validation category conflicts with the resolution flow from `task-351`, record the conflict explicitly and defer to the shared flow document until consistency is resolved
- if current validation surfaces in the repo use materially different category names, record the mapping rather than silently renaming live behavior

# Output

Produce `docs/installer/validation-categories.md` with these sections:

## Validation failure categories

For each category, document:
- Category name
- When it triggers (condition)
- Error message format
- Example input that triggers it
- Example error output

Categories to define:
1. `malformed_input` — invalid flag values, missing required fields, wrong types
2. `unknown_reference` — references to non-existent targets, profiles, or components
3. `compatibility_failure` — resolved state conflicts (e.g., two components require different versions of same dependency)
4. `preservation_conflict` — installer action conflicts with product-owned preservation rule
5. `backend_unavailable` — required backend not available for target
6. `migration_incompatible` — old config format cannot be migrated to new format

## Compatibility checks

For each compatibility check, document:
- Check name
- What it validates
- Input required
- Output (pass/fail with details)
- Example scenario

Checks to define:
1. `component_version_compatibility` — resolved component versions do not conflict
2. `target_backend_compatibility` — target supports the required backend
3. `dependency_resolution_compatibility` — all dependencies resolve without circular references
4. `overlay_compatibility` — overlays do not conflict with each other

## Preservation-conflict handling

Document how preservation conflicts are detected and resolved:
- Detection: how the system identifies a preservation conflict
- Resolution strategy: what happens when a conflict is detected (fail-safe, warn-and-continue, etc.)
- Error message format for preservation conflicts
- Example scenario

## Extension-field handling

Document how extension fields in config files are handled:
- What extension fields are allowed
- How they are validated (schema check, type check, etc.)
- What happens with unknown extension fields (ignore, error, warn)
- Example extension field usage

# What not to change

- do not replace existing validation logic in `tools/validation/validate_ids.py`
- do not modify existing contract validation in `src/audiagentic/foundation/contracts/`
- do not introduce hardcoded-known-id validation patterns
- do not add validation categories beyond the six listed
- do not add compatibility checks beyond the four listed
- do not change error message formats for existing validation failures
- do not make validation silent (all failures must produce actionable error messages)

# Acceptance criteria

- [ ] all six validation failure categories are defined with condition, format, and example
- [ ] all four compatibility checks are defined with input, output, and example scenario
- [ ] preservation-conflict handling specifies detection, resolution strategy, and example
- [ ] extension-field handling specifies allowed fields, validation rules, and unknown-field behavior
- [ ] compatibility failures are clearly distinct from malformed input failures (no overlap in examples)
- [ ] backward-compatibility behavior is explicit for each migration-incompatible case
- [ ] reviewer can verify by checking that each example input would trigger the stated category
