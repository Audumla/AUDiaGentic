---
id: task-350
label: Freeze CLI commands, flags, and output envelopes
state: draft
summary: Define the exact command and flag surface plus JSON and human output rules for stage one.
spec_ref: spec-80
request_refs:
- request-32
standard_refs:
- standard-6
- standard-8
- standard-11
---

# Description

Keep CLI behavior explicit and implementation-safe while preserving thin-dispatch architecture.

# Inputs

Read before starting:
- `docs/installer/noun-layer-assignment.md` (output from task-348)
- `spec-80` — CLI contract spec
- `src/audiagentic/channels/cli/main.py` — current CLI entrypoint (read to understand existing dispatch pattern)
- `standard-8` — Python implementation standard (naming, typing, error handling)
- `standard-11` — component architecture standard (thin-surface rule)

# Output

Produce `docs/installer/cli-command-contract.md` with these sections:

## Command definitions

For each command (`install`, `update`, `uninstall`, `status`, `doctor`), document:
- Command name (exact string passed to CLI)
- Mutating or diagnostic
- Default mode (`plan` for mutating commands, always non-mutating for diagnostic)
- Required flags (none for these commands)
- Optional flags with accepted values
- Output format specification (human vs JSON envelope)
- Handler module path (exact file path where implementation lives)

## Flag specifications

For each flag, document:
- Flag name (e.g., `--mode`, `--project-root`, `--json`)
- Accepted values (e.g., `--mode` accepts `plan|apply|validate`)
- Whether repeatable (yes/no)
- Which commands accept it
- Validation rules (e.g., `--mode` only valid with mutating commands)

## JSON envelope structure

Document the exact JSON envelope fields:
```json
{
  "command": "<string>",
  "mode": "<plan|apply|validate>",
  "project_root": "<string>",
  "profile": "<string|null>",
  "targets": ["<string>"],
  "status": "<success|failure|partial>",
  "findings": ["<finding object>"],
  "steps": ["<step object>"]
}
```

## Human output boundaries

Document what human output may contain:
- Banners and headings (allowed)
- Summaries (allowed)
- Remediation hints (allowed)
- What human output must NOT contain (raw JSON, debug traces)

## Dispatch architecture

Document how `main.py` dispatches:
- Entry point function in `main.py` (exact name)
- Dispatch table or routing logic (how command string maps to handler)
- Installer helper module path (exact file path)
- How JSON vs human output mode is selected (which flag, default behavior)

## Verification test cases

List each verification case as a design-time documentation item with name, purpose, and pass criteria. These are not runnable tests in this task. This task defines the expected future test coverage; later implementation packets decide where actual tests are written.

List each verification case:
- `test_install_default_mode_plan` — `install` without `--mode` defaults to `plan`
- `test_update_default_mode_plan` — `update` without `--mode` defaults to `plan`
- `test_uninstall_default_mode_plan` — `uninstall` without `--mode` defaults to `plan`
- `test_status_non_mutating` — `status` never performs mutations regardless of `--mode`
- `test_doctor_non_mutating` — `doctor` never performs mutations regardless of `--mode`
- `test_json_no_banner` — `--json` output contains no banner text, only valid JSON envelope
- `test_unknown_profile_error` — unknown profile produces error distinguishing malformed input from unknown reference
- `test_unknown_target_error` — unknown target produces error distinguishing malformed input from unknown reference
- `test_invalid_mode_combination` — invalid mode+command produces error with specific message
- `test_thin_dispatch` — `main.py` contains no installer-specific logic (reviewer checks file)

# What not to change

- do not create a second installer CLI entrypoint (must extend `src/audiagentic/channels/cli/main.py`)
- do not embed target logic in command parser branches
- do not modify the existing `audiagentic` entrypoint behavior
- do not make JSON output depend on banner or terminal formatting helpers
- do not make target selection mandatory for current project-only behavior
- do not embed registry contents in CLI command handlers
- do not add commands beyond the five listed (install, update, uninstall, status, doctor)
- do not change existing command names or flag names
- do not claim the verification cases are implemented tests in this task

# Blocker handling

- if `src/audiagentic/channels/cli/main.py` is missing or substantially different, record the discovered dispatch shape and flag the difference as a blocker
- if handler module paths do not exist yet, mark them as planned new paths rather than pretending they already exist
- if `spec-80` conflicts with the architecture boundaries from `task-348`, record the conflict instead of redefining thin-dispatch rules locally

# Acceptance criteria

- [ ] all five commands from spec-80 are documented with exact handler module paths
- [ ] all flags from spec-80 are documented with accepted values and validation rules
- [ ] JSON envelope structure matches the schema above (all fields present)
- [ ] human output boundaries explicitly state what is allowed and what is forbidden
- [ ] dispatch architecture satisfies thin-surface rule (main.py delegates, does not implement)
- [ ] all ten verification cases are listed as documentation items with clear pass/fail criteria
- [ ] the output explicitly states that runnable tests are out of scope for this task
- [ ] handler module paths reference actual locations under `src/audiagentic/channels/cli/`
- [ ] reviewer can verify by checking that each handler path exists or is a valid new file path
