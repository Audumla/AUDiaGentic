# AUDiaGentic Rust + WebAssembly Component Model smoke

Greenfield foundation spike using Rust, WebAssembly Components, WIT and wasmCloud `wash-runtime`.

Pinned runtime source:

- wasmCloud commit: `998d4a75598a5269af07be2c21682f334f642eaa`
- workspace version at that commit: `2.7.0`
- Rust: `1.94.0`
- Wasmtime: `47.0.3`

## Run

Requirements: Rust toolchain, `wash` from the pinned wasmCloud commit, network access for first dependency/WIT resolution.

```bash
cargo install --git https://github.com/wasmCloud/wasmCloud.git \
  --rev 998d4a75598a5269af07be2c21682f334f642eaa \
  wash --locked --no-default-features

./scripts/smoke.sh
```

Expected terminal marker:

```text
DEFAULT_PROVIDER=workflow-default:smoke
ALTERNATE_PROVIDER=workflow-alt:smoke
MISSING_PROVIDER_REJECTED=...
AUDIT_CALLS=2
SMOKE_OK
```

See `ARCHITECTURE.md` for what this experiment is intended to prove.
