#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
"$ROOT/scripts/prepare-wit.sh"

for component in workflow-default workflow-alt process; do
  echo "==> building $component"
  (cd "$ROOT/components/$component" && wash build)
done
